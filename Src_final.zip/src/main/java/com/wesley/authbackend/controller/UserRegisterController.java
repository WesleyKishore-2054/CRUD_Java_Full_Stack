package com.wesley.authbackend.controller;

import com.wesley.authbackend.request.UserRequestRegister;
import com.wesley.authbackend.service.UserRegisterService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/auth")
public class UserRegisterController {
    private final UserRegisterService userRegisterService;

    @PostMapping("/register")
    public ResponseEntity<?> userRegister(@RequestBody UserRequestRegister request) {
        return userRegisterService.userRegister(request);
    }
}
