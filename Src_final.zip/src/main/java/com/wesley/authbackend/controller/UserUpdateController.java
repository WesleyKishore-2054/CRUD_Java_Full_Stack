package com.wesley.authbackend.controller;

import com.wesley.authbackend.request.UserRequestUpdate;
import com.wesley.authbackend.service.UserUpdateService;
import com.wesley.authbackend.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/auth")
public class UserUpdateController {

    private final UserUpdateService userUpdateService;

    @PutMapping("/update")
    public ResponseEntity<?> userUpdate(
            @RequestBody UserRequestUpdate request,
            @RequestHeader("Authorization") String authHeader
    ) {
        String token = authHeader.replace("Bearer ", "");
        String email = JwtUtil.extractEmail(token);
        return userUpdateService.userUpdate(email, request);
    }
}
