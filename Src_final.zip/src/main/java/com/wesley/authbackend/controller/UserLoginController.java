package com.wesley.authbackend.controller;

import com.wesley.authbackend.model.User;
import com.wesley.authbackend.request.UserRequestLogin;
import com.wesley.authbackend.service.UserLoginService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/auth")
@RequiredArgsConstructor

public class UserLoginController {
    private final UserLoginService userLoginService;
    @PostMapping("/login")
    public ResponseEntity<?> userLogin(@RequestBody UserRequestLogin request) {
        return userLoginService.userLogin(request);
    }
    @GetMapping("/user")
    public ResponseEntity<?> getCurrentUser(@RequestHeader("Authorization") String authHeader) {
        try {
            String token = authHeader.replace("Bearer ", "");
            User user = userLoginService.getUserFromToken(token);
            if (user != null) {
                return ResponseEntity.ok(user);
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid token");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage());
        }
    }
}
