package com.wesley.authbackend.request;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserRequestUpdate {
    String email;
    String name;
    String phoneNumber;
}
