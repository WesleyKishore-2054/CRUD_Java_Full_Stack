package com.wesley.authbackend.request;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserRequestRegister {
    private String name;
    private String email;
    private String password;
    private String confirmPassword;
    private String phoneNumber;
}
