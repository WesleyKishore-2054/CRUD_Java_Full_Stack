package com.wesley.authbackend.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String email;

    private String password;

    private String name; // Optional: add fields as needed

    @Column(name = "phone_number")
    private String phoneNumber; // Optional: add fields as needed
}
