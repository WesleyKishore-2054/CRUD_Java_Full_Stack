package com.wesley.authbackend.service;

import com.wesley.authbackend.model.User;
import com.wesley.authbackend.repository.UserRepository;
import com.wesley.authbackend.request.UserRequestUpdate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserUpdateService {
    private final UserRepository userRepository;

    public ResponseEntity<?> userUpdate(String email, UserRequestUpdate request) {
        try {
            User user = userRepository.findByEmail(email).orElse(null);

            if (user == null) {
                return ResponseEntity.status(404).body("User not found");
            }

            user.setName(request.getName());
            user.setPhoneNumber(request.getPhoneNumber());
            userRepository.save(user);
            return ResponseEntity.ok(user); // returning updated user details
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error updating user");
        }
    }
}
