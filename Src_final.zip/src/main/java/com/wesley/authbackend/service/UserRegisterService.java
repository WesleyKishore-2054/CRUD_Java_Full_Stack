package com.wesley.authbackend.service;

import com.wesley.authbackend.model.User;
import com.wesley.authbackend.repository.UserRepository;
import com.wesley.authbackend.request.UserRequestRegister;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserRegisterService {

    private final UserRepository userRepository;

    public ResponseEntity<?> userRegister(UserRequestRegister request) {
        try {
            User existingUser = userRepository.findByEmail(request.getEmail()).orElse(null);

            if (existingUser != null) {
                if (existingUser.getPassword().equals(request.getPassword())) {
                    return ResponseEntity.ok(existingUser);
                } else {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid password");
                }
            }

            if (!request.getPassword().equals(request.getConfirmPassword())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Passwords do not match");
            }

            User newUser = new User();
            newUser.setEmail(request.getEmail());
            newUser.setPassword(request.getPassword());
            newUser.setName(request.getName());
            newUser.setPhoneNumber(request.getPhoneNumber());
            userRepository.save(newUser);

            return ResponseEntity.status(HttpStatus.CREATED).body(newUser);

        } catch (Exception e) {
            log.error("Registration failed", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something went wrong");
        }
    }
}
