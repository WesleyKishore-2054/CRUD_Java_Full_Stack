package com.wesley.authbackend.service;

import com.wesley.authbackend.repository.UserRepository;
import com.wesley.authbackend.request.UserRequestLogin;
import com.wesley.authbackend.util.JwtUtil;
import com.wesley.authbackend.model.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserLoginService {

    private final UserRepository userRepository;

    public ResponseEntity<?> userLogin(UserRequestLogin userRequestLogin) {
        try {
            User user = userRepository.findByEmailAndPassword(
                    userRequestLogin.getEmail(),
                    userRequestLogin.getPassword()
            ).orElseThrow(() -> new RuntimeException("Invalid email or password"));

            String token = JwtUtil.generateToken(userRequestLogin.getEmail());
            Map<String, Object> response = new HashMap<>();
            response.put("token", token);
            response.put("user", user);
            return ResponseEntity.ok(response);

        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Unexpected error");
        }
    }
    public User getUserFromToken(String token) {
        String email = JwtUtil.extractEmail(token);
        return userRepository.findByEmail(email).orElse(null);
    }
}
