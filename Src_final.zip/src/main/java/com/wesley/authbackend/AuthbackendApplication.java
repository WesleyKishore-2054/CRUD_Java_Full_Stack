package com.wesley.authbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthbackendApplication.class, args);

	}

}
