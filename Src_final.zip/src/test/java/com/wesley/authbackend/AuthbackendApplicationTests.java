package com.wesley.authbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
